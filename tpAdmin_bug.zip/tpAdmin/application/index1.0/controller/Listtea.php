<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Session;
class Listtea extends Controller{
    public function per(){
    	$user_id=Session::get('user_id');

        $res = Db::name('students')->alias('stu')
        		->join('teacherinfo tea','tea.cid=stu.cid')
            	->join('classes cla','cla.cid=stu.cid')
                ->where('stu.id',$user_id)
                ->where('types','0')
                ->select();

        $this->assign('datas',$res);
        return $this->fetch("per");
    }
      public function gui(){
    	$user_id=Session::get('user_id');

        $res = Db::name('students')->alias('stu')
        		->join('teacherinfo tea','tea.cid=stu.cid')
            	->join('classes cla','cla.cid=stu.cid')
            	->where('stu.id',$user_id)
                ->where('types','1')
            	->select();

            	
        $this->assign('datas',$res);
        return $this->fetch("gui");
    }
}