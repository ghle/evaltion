<?php
namespace app\index\controller;
use app\index\model\Students;
use think\Controller;
use think\Db;
use think\session;

class Register extends Controller {
    public function login()
    {
        if (!empty($_POST)) {
            $captcha = new \think\captcha\Captcha();
            if ($captcha->check($_POST['codes'])) {
                $users =new Students();
                $info = $users->checkNameAndPwd($_POST['name'], $_POST['password']);
                if ($info) {
                    session('user_id', $info['id']);

                    session('cid', $info['cid']);

              
                    session('user_name', $info['name']);

                    $this->redirect('Index/index');
                   
                } else {
                    echo "用户名或密码错误";
                }
            } else {
                echo "验证码错误";
            }
        }
        return $this->fetch("login");
    }
}