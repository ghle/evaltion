<?php
namespace app\index\model;
use think\Model;
class Students extends Model{
    function checkNameAndPwd($name,$password){
        $info = $this ->where("code='$name'")->find();
       dump($info);
        if($info){
            if($info['password']===$password)
                return $info;
        }
        return null;
    }
}