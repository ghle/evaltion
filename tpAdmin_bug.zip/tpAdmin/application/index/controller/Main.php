<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Session;
class Main extends Controller{
    
    public function index($id='',$types='')
      {
             header("content-type:text/html;charset=utf8");

            //教师类型
             session('types',$types);

            //当前老师ID
             session('tid',$id);
           
            // 当前学生id
            $user_id=Session::get('user_id');

            // 学生班级
            $stucla = Db::name('students')
                            ->alias('stu')
                            ->join('classes cla','cla.cid=stu.cid')
                            ->where('stu.id',$user_id)
                            ->select();

            // 教师部门信息     
            $teadept=Db::name('teacherinfo')
                                ->alias('tea')
                                ->join('depart dept','dept.did=tea.did')
                                ->where('tid',$id)
                                ->select();
                            
            // 调查问卷
              switch ($types) 
              {
                case '1':
                // （职业引导师）
                  $server=Db::name('guiderserver')->select();
                  break;
                 case '0':
                 // 专业教师
                   $server=Db::name('personal')->select();
                  break;

                default:
                      return $this->redirect("Index/index");
                  break;
              }
          
            $this->assign('stucla',$stucla);
            $this->assign('teadept',$teadept);
            $this->assign('server',$server);

            return $this->fetch("ceping");
      }

      // 数据结果
     public function showresult()
    {
      

        switch (Session::get('types')) {
          // 判断教师类型：0 是专业教师，1 是企业导员。
          case '0':$this->prodata();
            break;
           case '1':
                  $this->guidata();
            break;

          default:
            return 0;
            break;
        }
        Session::set('types',null);

    }

    public function guidata()
    {
            // 获取当前老师的id
          $tid=Session::get('tid');
          // 当前学生id
          $sid=Session::get('user_id');

          $cid=Session::get('cid');
      
           // 将数据插入临时的voting1中
            $sql="insert into tp_voting1 values(null, $tid, $sid,$cid,";

            
             if (count($_POST)<11) {
                $this->error("内容不全请重新评教","Main/index");
              }
           
            foreach ($_POST as $k=>$v)
            {
                        $sql.="$v,";
            }
            $sql=substr($sql,0,strlen($sql)-8);
            $sql.=");";
        
            $bol= Db::execute($sql);
           

             $sql="select tname 教师姓名,subjectname 学科,count(*) as 投票数,round(avg(";
            for($i=1;$i<=10;$i++)
               $sql.="q{$i}+";
             $sql=substr($sql,0,strlen($sql)-1);
             $sql.="),2) as 总分,";
             for($i=1;$i<=10;$i++)
               $sql.="round(avg(q{$i}),2) as s{$i},";
             $sql=substr($sql,0,strlen($sql)-1);
             $sql.= " from tp_voting1 a,tp_teacherinfo t where t.tid=a.tid and serid={$cid} and t.tid ={$tid} group by tname,subjectname order by 总分 desc;";




            $arr=Db::query($sql);
             
            $strinsert="insert into tp_guiderres(id,tname,subjectname,counts,avgnum,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,status,isdelete) values";
                foreach($arr as $key=>$value)
                {
                    $strinsert.="(null,'$value[教师姓名]','$value[学科]','$value[投票数]',$value[总分],$value[s1],$value[s2],$value[s3],$value[s4],$value[s5],$value[s6],$value[s7],$value[s8],$value[s9],$value[s10],1,0);";        
                }
               
               $co=$arr[0]['投票数']-1;

                $arr=Db::execute($strinsert);
                
                
                if ($arr) {

                    Db::name('guiderres')->where('counts',$co)->delete();
                    $this->success("评教成功","Index/index");
                }else {
                    $this->error("评教失败","Main/index");
                }
                
        }
 
    public function prodata()
      {
      	

            $perid=Session::get('tid');
            $sid=Session::get('user_id');
            $cid=Session::get('cid');
          //更改为专业教师的
          
            if (count($_POST)<17) {
                $this->error("内容不全请重新评教","Main/index");
            }

            $sql="insert into tp_voting2 values(null, $perid, $sid,$cid,";

            foreach ($_POST as $k=>$v)
            {
                        $sql.="$v,";
            }
            $sql=substr($sql,0,strlen($sql)-8);
            $sql.=");";



            $bol= Db::query($sql);
            
             $sql="select tname 教师姓名,subjectname 学科,count(*) as 投票数,round(avg(";
            for($i=1;$i<=16;$i++)
               $sql.="q{$i}+";
             $sql=substr($sql,0,strlen($sql)-1);
             $sql.="),2) as 总分,";
             for($i=1;$i<=16;$i++)
               $sql.="round(avg(q{$i}),2) as s{$i},";
             $sql=substr($sql,0,strlen($sql)-1);
             $sql.= " from tp_voting2 a,tp_teacherinfo t where t.cid=a.tid and serid={$cid} and t.tid ={$perid}  group by tname,subjectname order by 总分 desc;";
             // var_dump($sql);
             //    die();
             $arr=Db::query($sql);
            
            //更改为专业教师表
            $strinsert="insert into tp_personres(id,tname,subjectname,counts,avgnum,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,status,isdelete) values";
                foreach($arr as $key=>$value)
                {
                    $strinsert.="(null,'$value[教师姓名]','$value[学科]','$value[投票数]',$value[总分],$value[s1],$value[s2],$value[s3],$value[s4],$value[s5],$value[s6],$value[s7],$value[s8],$value[s9],$value[s10],$value[s11],$value[s12],$value[s13],$value[s14],$value[s15],$value[s16],1,0);";        
                }

               
               
               $co=$arr[0]['投票数']-1;
              
                $arr=Db::execute($strinsert);
     
                
                
                if ($arr) {
                    Session::set('perid',null);
                    $s=Db::name('personres')->where('counts',$co)->delete();
                    $this->success("评教成功","Index/index");

                }else {
                    $this->error("评教失败","Main/index");
                }
              


        

                
      }
     
}