<?php
namespace app\index\controller;
use think\Controller;
use think\db;
class Index extends Controller
{
    public function index()
    {

    	 if (session('user_id')) {
//             1、 根据用户id 信息获取本身的记录信息
             $user_id = session('user_id');
//             dump($user_id);
//             die;
            return $this->fetch("index");
         } else {
             $this->redirect('Register/login');
         }

       
    }
    public function main()
    {
        return $this->fetch();
    }
}
