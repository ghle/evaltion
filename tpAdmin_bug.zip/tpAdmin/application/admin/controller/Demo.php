<?php
/**
 * tpAdmin [a web admin based ThinkPHP5]
 *
 * @author yuan1994 <tianpian0805@gmail.com>
 * @link http://tpadmin.yuan1994.com/
 * @copyright 2016 yuan1994 all rights reserved.
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */

//------------------------
// 演示示例
//-------------------------

namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Exception;
use think\Request;
use mailer\tp5\Mailer;

class Demo extends Controller
{
    /**
     * Excel一键导出
     */


public function index(){

    return $this->fetch();
}
    public function excel()
    {
        if ($this->request->isPost()) {



            $data = Db::name("student")->field("id", true)->order("id desc")->limit(20)->select();
            $date=array();
            foreach ($data as $key => $value) {
                $arr=$data[$key];
            }
            $date[0]=array_keys($arr);
            if ($error = \Excel::export($date[0], $data, "示例Excel导出", '2007')) {
                throw new Exception($error);
            }
        } else {
            return $this->view->fetch();
        }
    }

    public  function  imports(){

        if ($this->request->isPost()) {
            // 获取表单上传文件 例如上传了001.jpg
            $file = request()->file('excel');
            // 移动到框架应用根目录/public/uploads/ 目录下
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'Excel','');
                if($info){
                    // 解析 Excel 头部信息，返回 $excelHeader = ['A' => '第一行A列描述', 'B' => '第一行B列描述', 'C' => '第一行C列描述',...]
                    $excelHeader = \Excel::parseHeader($info->getPathname(), '');

//                  将头部信息 遍历出来  作为数据表的字段 自动创建表格
                    $colume=array_values($excelHeader);

                   $dbname=substr($info->getFilename(),0,-4);

                    $createtable=" CREATE TABLE IF NOT EXISTS `tp_{$dbname}` (
                    `id` int(11)  auto_increment,";
                    for($i=0;$i<count($colume);$i++){
                            $createtable.="`$colume[$i]` varchar(25)," ;
                    }
                    $createtable.=" `status` int(10) default 1,
                                `isdelete` int(10) default 0,
                    ";
                    $createtable.="PRIMARY KEY  (`id`));";
                 

                    Db::execute($createtable);
//
//                   将数据循环导入数据库中
                    vendor('phpoffice.phpexcel.PHPExcel');
                    $objReader =\PHPExcel_IOFactory::createReader('Excel5');
                    $objPHPExcel = $objReader->load($info->getPathname(), $encode = 'utf-8');
                    $excel_array = $objPHPExcel->getsheet(0)->toArray();   //转换为数组格式
                    array_shift($excel_array);  //删除第一个数组(标题);
                    $city = [];
                    foreach($excel_array as $k=>$v) {
                            for($c=0;$c<count($colume);$c++){
                                $city[$k][$colume[$c]] = $v[$c];
                            }

                    }
                    Db::name("{$dbname}")->insertAll($city); //批量插入数据

                }else{
                    // 上传失败获取错误信息
                    echo $file->getError();
                }
            }

//
        }

    }


    /**
     * 下载文件
     * @return mixed
     */
    public function download()
    {
        if ($this->request->param('file')) {
            return \File::download("../README.md");
        } else {
            return $this->view->fetch();
        }
    }

    /**
     * 下载远程图片
     * @return mixed
     */
    public function downloadImage()
    {
        if (Request::instance()->isPost()) {
            $url = $this->request->post("url");
            if (substr($url, 0, 4) != "http") {
                return ajax_return_adv_error("url非法");
            }
            $name = "./tmp/" . get_random();
            $filename = \File::downloadImage($url, $name);
            if (!$filename) {
                return ajax_return_adv_error($filename);
            } else {
                $url = $this->request->root() . substr($filename, 1);

                return ajax_return_adv("下载成功", '', "图片下载成功，<a href='{$url}' target='_blank' class='c-blue'>点击查看</a><br>{$url}");
            }
        } else {
            return $this->view->fetch();
        }
    }

    /**
     * 发送邮件
     * @return mixed
     */
    public function mail()
    {
        if ($this->request->isPost()) {
            $receive = $this->request->post("receiver");
            $result = $this->validate(
                ['receiver' => $receive],
                ['receiver|收件人' => 'require|email']
            );
            if ($result !== true) {
                return ajax_return_adv_error($result);
            }
            $mailer = Mailer::instance();
            $result = $mailer->to($receive)
                ->subject('来自tpadmin的测试邮件')
                ->view('mail_template')
                ->send();

            if ($result == 0) {
                return ajax_return_adv_error($mailer->getError());
            } else {
                return ajax_return_adv("邮件发送成功，请注意查收", '');
            }
        } else {
            return $this->view->fetch();
        }
    }

    /**
     * 百度编辑器
     * @return mixed
     */
    public function ueditor()
    {
        return $this->view->fetch();
    }

    /**
     * 七牛上传
     * @return mixed
     */
    public function qiniu()
    {
        if ($this->request->isPost()) {
            return '<script>parent.layer.alert("仅做演示")</script>';
            /*$result = \Qiniu::instance()->upload();
            p($result);*/
        } else {
            return $this->view->fetch();
        }
    }

    /**
     * ID加密
     * @return mixed
     */
    public function hashids()
    {
        if ($this->request->isPost()) {
            $id = $this->request->post("id");
            $hashids = \Hashids\Hashids::instance(8, "tpadmin");
            $encode_id = $hashids->encode($id); //加密
            $decode_id = $hashids->decode($encode_id); //解密
            return ajax_return_adv("操作成功", '', false, '', '', ['encode' => $encode_id, 'decode' => $decode_id]);
        } else {
            return $this->view->fetch();
        }
    }

    /**
     * 丰富弹层
     */
    public function layer()
    {
        return $this->view->fetch();
    }

    /**
     * 表格溢出
     */
    public function tableFixed()
    {
        return $this->view->fetch();
    }

    /**
     * 图片上传回调
     */
    public function imageUpload()
    {
        return $this->view->fetch();
    }

    /**
     * 二维码生成
     */
    public function qrcode()
    {
        return $this->view->fetch();
    }
}