<?php

return array (
  'module' => 'admin',
  'menu' => 
  array (
    0 => 'add',
    1 => 'forbid',
    2 => 'resume',
    3 => 'delete',
    4 => 'recyclebin',
    5 => 'saveorder',
  ),
  'create_config' => true,
  'controller' => 'Guiderres',
  'title' => '',
  'form' => 
  array (
    0 => 
    array (
      'title' => '教师姓名',
      'name' => 'tname',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    1 => 
    array (
      'title' => '学科',
      'name' => 'subjectname',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    2 => 
    array (
      'title' => '投票数',
      'name' => 'counts',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    3 => 
    array (
      'title' => '总分',
      'name' => 'avgnum',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    4 => 
    array (
      'title' => 's1',
      'name' => 's1',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    5 => 
    array (
      'title' => 's2',
      'name' => 's2',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    6 => 
    array (
      'title' => 's3',
      'name' => 's3',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    7 => 
    array (
      'title' => 's4',
      'name' => 's4',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    8 => 
    array (
      'title' => 's5',
      'name' => 's5',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    9 => 
    array (
      'title' => 's6',
      'name' => 's6',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    10 => 
    array (
      'title' => 's7',
      'name' => 's7',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    11 => 
    array (
      'title' => 's8',
      'name' => 's8',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    12 => 
    array (
      'title' => 's9',
      'name' => 's9',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    13 => 
    array (
      'title' => 's10',
      'name' => 's10',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
  ),
  'create_table' => '1',
  'table_engine' => 'InnoDB',
  'table_name' => '',
  'field' => 
  array (
    1 => 
    array (
      'name' => 'tname',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => '教师姓名',
      'extra' => '',
    ),
    2 => 
    array (
      'name' => 'subjectname',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => '学科',
      'extra' => '',
    ),
    3 => 
    array (
      'name' => 'counts',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => '投票数',
      'extra' => '',
    ),
    4 => 
    array (
      'name' => 'avgnum',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => '总分',
      'extra' => '',
    ),
    5 => 
    array (
      'name' => 's1',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's1',
      'extra' => '',
    ),
    6 => 
    array (
      'name' => 's2',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's2',
      'extra' => '',
    ),
    7 => 
    array (
      'name' => 's3',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's3',
      'extra' => '',
    ),
    8 => 
    array (
      'name' => 's4',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's4',
      'extra' => '',
    ),
    9 => 
    array (
      'name' => 's5',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's5',
      'extra' => '',
    ),
    10 => 
    array (
      'name' => 's6',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's6',
      'extra' => '',
    ),
    11 => 
    array (
      'name' => 's7',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's7',
      'extra' => '',
    ),
    12 => 
    array (
      'name' => 's8',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's8',
      'extra' => '',
    ),
    13 => 
    array (
      'name' => 's9',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's9',
      'extra' => '',
    ),
    14 => 
    array (
      'name' => 's10',
      'type' => 'varchar(255)',
      'default' => 'NULL',
      'comment' => 's10',
      'extra' => '',
    ),
  ),
);
